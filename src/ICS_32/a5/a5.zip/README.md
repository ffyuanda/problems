Welcome to my a5 assignment, just run DistributedSocialGUI.py will be good.

Basic info are hard-coded:
port = 2021
server = 168.235.86.101
username = ffyuanda
pwd = ffyuanda123

I have 5 extra-credit features:

1. Add title support for posts

    You can add a title to the post by writing in the first line in the entry
    widget. The program will convert whatever on the first line in the entry to be
    the title and display it in the posts list.
    
2. Add support for post editing

    There are two buttons which are "Save Post" and "Add Post". After you selected
    a post in the posts list, you can edit its title(first line) and entry, 
    and when you finished editing, click "Save Post", then the post is edited and saved.
    
    If you want to add one more post, simply click "Add Post", it will create a
    post with title "TYPE TITLE HERE" and entry "TYPE ENTRY HERE" as default value.
    You can then go ahead edit and save them.
    
3. Add settings menu item and interface

    You can find the "Settings" tab on the main interface, click it then click
    "Current keys" the public and private keys will be displayed. And you can modify
    them as you wish, then click "save to the profile" to save them. But once you
    changed the keys, the profile won't be able to get properly encrypted or
    decrypted, so use this function wisely. 
    
4. Add support for deleting the post

    You first select a post, then click "Delete Post", and that's deleted!

5. Add a README.md display and edit support

    Actually I'm writing this line using this bonus feature! You can click "Others" 
    in the main interface, then click "Show README", then you will enter an edit-and-save 
    mode to read and modify README.md. If you want to save it, just click "Save README". And
    you will be all good!

6. Other small features
 
    footer_label can display various messages from the
    system and change back to "Ready." after displaying.
    
    colored buttons and messages
    
    to be continued...